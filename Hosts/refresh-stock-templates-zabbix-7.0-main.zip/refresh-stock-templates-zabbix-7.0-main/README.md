# refresh-stock-templates-zabbix-7.0
 Use Zabbix API, PHP, bash to renew and overwrite all stock templates
